# Entrega: proposta e NER básico

Ibmec Faria Lima — Ciência de Dados e Inteligência Artificial
Caio Jardim e Hugo Toledo

Conforme adaptação de escopo informada pelo grupo, a entrega é proposta + NER. O roteiro original denomina NER como etapa 3; não há experimento de sentimentos neste pacote.

## Arquivos

- reports/proposta.pdf: proposta em duas páginas.
- reports/proposta.md: fonte editável da proposta.
- notebooks/03_ner_basico_entrega.ipynb: experimento executado com objetivo, metodologia, código, saídas e análise de erros.
- reports/ner_basico_v1/: padrões, casos, entidades, métricas e configuração.

## Execução

Abra a pasta extraída como projeto no VS Code. Foi utilizado Python 3.13, spaCy 3.8.16 e pt_core_news_sm 3.8.0.

Instale as dependências no ambiente escolhido:

    python -m pip install -r requirements.txt
    python -m spacy download pt_core_news_sm-3.8.0 --direct

Selecione esse Python como kernel e execute o notebook em ordem, a partir da raiz da pasta extraída ou de notebooks/. Os resultados existentes idênticos são conferidos sem sobrescrita; resultados diferentes interrompem a exportação. A reprodução completa da cópia de entrega foi verificada em um kernel novo, no ambiente local utilizado pelo grupo.

## Resultado e limites

Piloto por regras: 12 padrões, oito frases sintéticas e nove entidades de referência. Resultado global micro: VP=9, FP=2, FN=0; precisão 81,82%, revocação 100%, F1 90%. Os falsos positivos são os verbos matricula e estagio.

O modelo pré-treinado teve comparação qualitativa em uma pergunta. As métricas avaliam apenas o EntityRuler. Não houve treinamento pelo grupo. O piloto é pequeno, foi elaborado com conhecimento das regras e não mede generalização em uso real. Anotações propostas com apoio de IA; revisão humana ainda não registrada.

As cópias originais dos documentos institucionais e o corpus extraído não estão incluídos neste pacote.
